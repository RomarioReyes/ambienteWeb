<?php
if ($_POST) {
    
    $var2 = $_REQUEST['categorias'];
    echo($var2);
 
    
    

}

  
// $id = $_GET['cars'];
// echo($id);
?>